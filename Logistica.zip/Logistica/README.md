Como rodar o projecto baixado
Instalar todas as dependências indicada pelo package.json
### npm install

Rodar o projecto com nodemon
### nodemon probum.js

Criar o arquivo package
### npm init

Gerencia requesições, rota, urls, entre outras funcionalidades
### npm install express

Acessar o projecto no navegador
### http://localhost:8050

Instalar o módulo para reiniciar o servidor sempre que houver alteração no código 
### npm install -g nodemom
### npm install --save-dev nodemon

comando que define a política de execução para permitir a execução de scripts assinados localmente
### Set-ExecutionPolicy RemoteSigned -Scope CurrentUser

instalar o handlebars para criar layout padrão para o projecto 
### npm install --save express-handlebars



sequelize é uma biblioteca javascript que facilita o gerenciamento de um banco de dados SQL
### npm instal --save sequelize

Instalar o drive do banco de dados
### npm instal --save mysql2

permite levar os valores do formulário para o banco de dados
### npm install --save body-parser

extensão para trabalhar com datas e outros
### npm install --save moment